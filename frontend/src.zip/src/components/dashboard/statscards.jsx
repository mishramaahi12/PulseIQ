import { useEffect, useState } from "react";

import {
  IndianRupee,
  ShoppingBag,
  Users,
  WalletCards,
} from "lucide-react";

function formatINR(value) {
  const number = Number(value) || 0;

  if (number >= 10000000) {
    return `₹${(number / 10000000).toFixed(2)}Cr`;
  }

  if (number >= 100000) {
    return `₹${(number / 100000).toFixed(2)}L`;
  }

  if (number >= 1000) {
    return `₹${(number / 1000).toFixed(1)}K`;
  }

  return `₹${number.toLocaleString("en-IN")}`;
}

function getLocalData() {
  try {
    const data = JSON.parse(
      localStorage.getItem("pulseiq_business_data") || "[]"
    );

    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function calculateLocalStats(rows) {
  if (!rows.length) {
    return null;
  }

  const revenue = rows.reduce((sum, row) => {
    return (
      sum +
      (Number(row.totalAmount) ||
        Number(row.total_amount) ||
        Number(row.total) ||
        0)
    );
  }, 0);

  const customers = new Set(
    rows
      .map(
        (row) =>
          row.customerName ||
          row.customer_name ||
          row.customer ||
          ""
      )
      .map((value) => String(value).trim())
      .filter(Boolean)
  ).size;

  const invoiceIds = new Set(
    rows
      .map(
        (row) =>
          row.invoiceId ||
          row.invoice_id ||
          row.orderId ||
          row.order_id ||
          ""
      )
      .map((value) => String(value).trim())
      .filter(Boolean)
  );

  const orders =
    invoiceIds.size > 0
      ? invoiceIds.size
      : rows.length;

  return {
    revenue,
    orders,
    customers,
    profit: 0,
    growth: null,
    source: "actual",
  };
}

function getUserId() {
  const direct =
    localStorage.getItem("pulseiq_user_id");

  if (direct) {
    return direct;
  }

  try {
    const user = JSON.parse(
      localStorage.getItem("pulseiq_user") || "null"
    );

    return user?.id || user?.user_id || null;
  } catch {
    return null;
  }
}

function StatsCards() {
  const [stats, setStats] = useState({
    revenue: 0,
    orders: 0,
    customers: 0,
    profit: 0,
    growth: null,
    source: "demo",
  });

  const [loading, setLoading] = useState(true);

  const loadDashboard = async () => {
    setLoading(true);

    try {
      const localRows = getLocalData();
      const localStats = calculateLocalStats(localRows);

      if (localStats) {
        setStats(localStats);
        setLoading(false);
        return;
      }

      const userId = getUserId();

      if (!userId) {
        setStats((previous) => ({
          ...previous,
          source: "demo",
        }));

        setLoading(false);
        return;
      }

      const response = await fetch(
        "http://127.0.0.1:8000/dashboard",
        {
          headers: {
            "X-User-Id": String(userId),
          },
        }
      );

      if (!response.ok) {
        throw new Error("Dashboard request failed");
      }

      const data = await response.json();

      setStats({
        revenue: Number(data.revenue) || 0,
        orders: Number(data.orders) || 0,
        customers: Number(data.customers) || 0,
        profit: Number(data.profit) || 0,
        growth:
          data.growth !== null &&
          data.growth !== undefined
            ? Number(data.growth)
            : null,
        source: data.source || "demo",
      });
    } catch (error) {
      console.error(
        "Dashboard stats error:",
        error
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();

    const handleUpdate = () => {
      loadDashboard();
    };

    window.addEventListener(
      "pulseiq-data-updated",
      handleUpdate
    );

    window.addEventListener(
      "pulseiq-dataset-updated",
      handleUpdate
    );

    window.addEventListener(
      "storage",
      handleUpdate
    );

    return () => {
      window.removeEventListener(
        "pulseiq-data-updated",
        handleUpdate
      );

      window.removeEventListener(
        "pulseiq-dataset-updated",
        handleUpdate
      );

      window.removeEventListener(
        "storage",
        handleUpdate
      );
    };
  }, []);

  const growthValue =
    stats.growth !== null &&
    stats.growth !== undefined
      ? Number(stats.growth)
      : null;

  const cards = [
    {
      title: "Revenue",
      value: loading
        ? "..."
        : formatINR(stats.revenue),

      change:
        growthValue !== null
          ? `${growthValue >= 0 ? "+" : ""}${growthValue.toFixed(1)}%`
          : stats.source === "actual"
          ? "From your data"
          : "Demo data",

      icon: IndianRupee,
    },

    {
      title: "Orders",
      value: loading
        ? "..."
        : stats.orders.toLocaleString("en-IN"),

      change:
        stats.source === "actual"
          ? "From your data"
          : "Demo data",

      icon: ShoppingBag,
    },

    {
      title: "Customers",
      value: loading
        ? "..."
        : stats.customers.toLocaleString("en-IN"),

      change:
        stats.source === "actual"
          ? "Unique customers"
          : "Demo data",

      icon: Users,
    },

    {
      title: "Profit",
      value: loading
        ? "..."
        : formatINR(stats.profit),

      change:
        stats.source === "actual"
          ? stats.profit > 0
            ? "From your data"
            : "No profit column"
          : "Demo data",

      icon: WalletCards,
    },
  ];

  return (
    <div className="stats-grid">
      {cards.map((card) => {
        const Icon = card.icon;

        return (
          <div
            key={card.title}
            className="stat-card hover-lift"
          >
            <div className="stat-top">
              <div className="stat-icon">
                <Icon size={20} />
              </div>

              <span className="stat-change">
                {card.change}
              </span>
            </div>

            <p>{card.title}</p>

            <h2>{card.value}</h2>
          </div>
        );
      })}
    </div>
  );
}

export default StatsCards;