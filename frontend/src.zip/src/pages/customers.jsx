import { useEffect, useMemo, useState, useCallback } from "react";

import {
  Users,
  Search,
  Database,
  RefreshCw,
  UserPlus,
  ChevronLeft,
  ChevronRight,
  IndianRupee,
  CreditCard,
  Clock3,
  TrendingUp,
  SlidersHorizontal,
  Check,
} from "lucide-react";

import Sidebar from "../components/dashboard/sidebar";
import Topbar from "../components/dashboard/topbar";

import "./customers.css";

const CUSTOMERS_PER_PAGE = 50;

function Customers() {
  const [customers, setCustomers] = useState([]);
  const [customerColumn, setCustomerColumn] = useState(null);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  const [currentPage, setCurrentPage] = useState(1);

  // =========================================================
  // FILTER
  // =========================================================

  const [activeFilter, setActiveFilter] = useState("all");
  const [filterOpen, setFilterOpen] = useState(false);

  // =========================================================
  // FILTER OPTIONS
  // =========================================================

  const filterOptions = [
    {
      id: "all",
      label: "All Customers",
      description: "Show every customer",
    },
    {
      id: "paid",
      label: "Paid",
      description: "Customers with no pending payment",
    },
    {
      id: "pending",
      label: "Pending",
      description: "Customers with outstanding payment",
    },
    {
      id: "high",
      label: "Highly Paid",
      description: "Top 20% by total spending",
    },
    {
      id: "low",
      label: "Low Spending",
      description: "Bottom 20% by total spending",
    },
    {
      id: "most",
      label: "Most Purchases",
      description: "Top 20% by purchase count",
    },
    {
      id: "least",
      label: "Least Purchases",
      description: "Bottom 20% by purchase count",
    },
  ];

  // =========================================================
  // LOAD CUSTOMERS
  // =========================================================

  const loadCustomers = useCallback((isRefresh = false) => {
    if (isRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    setError("");

    try {
      const savedBusinessData = localStorage.getItem(
        "pulseiq_business_data"
      );

      const rows = savedBusinessData
        ? JSON.parse(savedBusinessData)
        : [];

      if (!Array.isArray(rows) || rows.length === 0) {
        setCustomers([]);
        setCustomerColumn(null);
        setCurrentPage(1);
        return;
      }

      const customerMap = new Map();

      rows.forEach((row) => {
        const name =
          String(row?.customerName || "").trim() ||
          "Unknown Customer";

        if (!customerMap.has(name)) {
          customerMap.set(name, {
            name,
            purchases: [],
            totalSpent: 0,
            totalPaid: 0,
            totalPending: 0,
          });
        }

        const customer = customerMap.get(name);

        const amount = Number(row?.totalAmount) || 0;

        const status =
          String(row?.paymentStatus || "").toLowerCase() ===
          "pending"
            ? "Pending"
            : "Paid";

        customer.purchases.push({
          product: row?.product || "Item",
          quantity: row?.quantity,
          amount,
          status,
          date: row?.purchaseDate || "",
          invoiceId: row?.invoiceId || "",
        });

        customer.totalSpent += amount;

        if (status === "Pending") {
          customer.totalPending += amount;
        } else {
          customer.totalPaid += amount;
        }
      });

      const customerList = Array.from(customerMap.values())
        .map((customer) => ({
          ...customer,
          purchaseCount: customer.purchases.length,
          hasPending: customer.totalPending > 0,
        }))
        .sort((a, b) => b.totalSpent - a.totalSpent);

      setCustomers(customerList);
      setCustomerColumn("Customer Name");
      setCurrentPage(1);
    } catch (err) {
      console.error("Customers loading error:", err);

      setError(
        "Unable to read your saved business data. Try re-uploading it from the Upload Data page."
      );

      setCustomers([]);
      setCustomerColumn(null);
      setCurrentPage(1);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  // =========================================================
  // INITIAL LOAD + LIVE DATA UPDATE
  // =========================================================

  useEffect(() => {
    loadCustomers();

    const handleDataUpdate = () => {
      loadCustomers(true);
    };

    window.addEventListener(
      "pulseiq-data-updated",
      handleDataUpdate
    );

    return () => {
      window.removeEventListener(
        "pulseiq-data-updated",
        handleDataUpdate
      );
    };
  }, [loadCustomers]);

  // =========================================================
  // SMART CUSTOMER FILTER
  // =========================================================

  const filteredByType = useMemo(() => {
    if (customers.length === 0) {
      return [];
    }

    if (activeFilter === "all") {
      return customers;
    }

    if (activeFilter === "paid") {
      return customers.filter(
        (customer) => !customer.hasPending
      );
    }

    if (activeFilter === "pending") {
      return customers.filter(
        (customer) => customer.hasPending
      );
    }

    const getTopBottomTwentyPercent = (
      list,
      valueGetter,
      direction
    ) => {
      if (list.length === 0) {
        return [];
      }

      const sorted = [...list].sort((a, b) => {
        const aValue = valueGetter(a);
        const bValue = valueGetter(b);

        return direction === "desc"
          ? bValue - aValue
          : aValue - bValue;
      });

      const count = Math.max(
        1,
        Math.ceil(sorted.length * 0.2)
      );

      return sorted.slice(0, count);
    };

    if (activeFilter === "high") {
      return getTopBottomTwentyPercent(
        customers,
        (customer) => customer.totalSpent,
        "desc"
      );
    }

    if (activeFilter === "low") {
      return getTopBottomTwentyPercent(
        customers,
        (customer) => customer.totalSpent,
        "asc"
      );
    }

    if (activeFilter === "most") {
      return getTopBottomTwentyPercent(
        customers,
        (customer) => customer.purchaseCount,
        "desc"
      );
    }

    if (activeFilter === "least") {
      return getTopBottomTwentyPercent(
        customers,
        (customer) => customer.purchaseCount,
        "asc"
      );
    }

    return customers;
  }, [customers, activeFilter]);

  // =========================================================
  // SEARCH + FILTER
  // =========================================================

  const filteredCustomers = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return filteredByType;
    }

    return filteredByType.filter((customer) =>
      String(customer.name || "")
        .toLowerCase()
        .includes(query)
    );
  }, [filteredByType, search]);

  // =========================================================
  // SUMMARY CALCULATIONS
  // =========================================================

  const customerStats = useMemo(() => {
    const totalRevenue = customers.reduce(
      (sum, customer) => sum + customer.totalSpent,
      0
    );

    const totalPaid = customers.reduce(
      (sum, customer) => sum + customer.totalPaid,
      0
    );

    const totalPending = customers.reduce(
      (sum, customer) => sum + customer.totalPending,
      0
    );

    const averageSpend =
      customers.length > 0
        ? totalRevenue / customers.length
        : 0;

    return {
      totalRevenue,
      totalPaid,
      totalPending,
      averageSpend,
    };
  }, [customers]);

  // =========================================================
  // PAGINATION
  // =========================================================

  const totalPages = Math.max(
    1,
    Math.ceil(
      filteredCustomers.length / CUSTOMERS_PER_PAGE
    )
  );

  const safeCurrentPage = Math.min(
    currentPage,
    totalPages
  );

  const visibleCustomers = useMemo(() => {
    const start =
      (safeCurrentPage - 1) * CUSTOMERS_PER_PAGE;

    return filteredCustomers.slice(
      start,
      start + CUSTOMERS_PER_PAGE
    );
  }, [filteredCustomers, safeCurrentPage]);

  const pageStart =
    filteredCustomers.length === 0
      ? 0
      : (safeCurrentPage - 1) * CUSTOMERS_PER_PAGE + 1;

  const pageEnd = Math.min(
    safeCurrentPage * CUSTOMERS_PER_PAGE,
    filteredCustomers.length
  );

  // =========================================================
  // HANDLERS
  // =========================================================

  const handleSearch = (event) => {
    setSearch(event.target.value);
    setCurrentPage(1);
  };

  const handleFilterChange = (filterId) => {
    setActiveFilter(filterId);
    setCurrentPage(1);
    setFilterOpen(false);
  };

  const goToPreviousPage = () => {
    setCurrentPage((page) => Math.max(1, page - 1));
  };

  const goToNextPage = () => {
    setCurrentPage((page) =>
      Math.min(totalPages, page + 1)
    );
  };

  // =========================================================
  // HELPERS
  // =========================================================

  const formatCurrency = (value) => {
    return `₹${Number(value || 0).toLocaleString("en-IN", {
      maximumFractionDigits: 2,
    })}`;
  };

  const getInitial = (name) => {
    return (
      String(name || "?")
        .trim()
        .charAt(0)
        .toUpperCase() || "?"
    );
  };

  const activeFilterLabel =
    filterOptions.find(
      (option) => option.id === activeFilter
    )?.label || "All Customers";

  // =========================================================
  // UI
  // =========================================================

  return (
    <div className="dashboard-shell">
      <Sidebar />

      <div className="dashboard-main">
        <Topbar />

        <main className="dashboard-content customers-page">
          {/* =================================================
              PAGE HEADING
          ================================================= */}

          <div className="page-heading customers-page-heading">
            <div>
              <span className="eyebrow">CUSTOMERS</span>

              <h1>
                Manage and understand your customers.
              </h1>

              <p>
                Track customer purchases, revenue and
                payment activity from your business data.
              </p>
            </div>

            <button
              type="button"
              className="customer-refresh-button"
              onClick={() => loadCustomers(true)}
              disabled={loading || refreshing}
            >
              <RefreshCw
                size={17}
                className={
                  refreshing
                    ? "customer-refresh-spin"
                    : ""
                }
              />

              {refreshing ? "Refreshing..." : "Refresh"}
            </button>
          </div>

          {/* =================================================
              ERROR
          ================================================= */}

          {error && (
            <div className="customers-error">
              {error}
            </div>
          )}

          {/* =================================================
              SUMMARY
          ================================================= */}

          <div className="customers-summary-grid">
            <div className="dashboard-card customer-summary-card">
              <div className="customer-summary-icon">
                <Users size={22} />
              </div>

              <div className="customer-summary-content">
                <span>TOTAL CUSTOMERS</span>

                <strong>
                  {loading
                    ? "..."
                    : customers.length.toLocaleString()}
                </strong>

                <small>
                  Unique customers detected
                </small>
              </div>
            </div>

            <div className="dashboard-card customer-summary-card">
              <div className="customer-summary-icon revenue-icon">
                <IndianRupee size={22} />
              </div>

              <div className="customer-summary-content">
                <span>TOTAL REVENUE</span>

                <strong>
                  {loading
                    ? "..."
                    : formatCurrency(
                        customerStats.totalRevenue
                      )}
                </strong>

                <small>
                  Total customer spending
                </small>
              </div>
            </div>

            <div className="dashboard-card customer-summary-card">
              <div className="customer-summary-icon paid-icon">
                <CreditCard size={22} />
              </div>

              <div className="customer-summary-content">
                <span>PAID AMOUNT</span>

                <strong>
                  {loading
                    ? "..."
                    : formatCurrency(
                        customerStats.totalPaid
                      )}
                </strong>

                <small>
                  Successfully collected
                </small>
              </div>
            </div>

            <div className="dashboard-card customer-summary-card">
              <div className="customer-summary-icon pending-icon">
                <Clock3 size={22} />
              </div>

              <div className="customer-summary-content">
                <span>PENDING AMOUNT</span>

                <strong>
                  {loading
                    ? "..."
                    : formatCurrency(
                        customerStats.totalPending
                      )}
                </strong>

                <small>
                  Outstanding payments
                </small>
              </div>
            </div>

            <div className="dashboard-card customer-summary-card">
              <div className="customer-summary-icon average-icon">
                <TrendingUp size={22} />
              </div>

              <div className="customer-summary-content">
                <span>AVG. CUSTOMER SPEND</span>

                <strong>
                  {loading
                    ? "..."
                    : formatCurrency(
                        customerStats.averageSpend
                      )}
                </strong>

                <small>
                  Average revenue per customer
                </small>
              </div>
            </div>

            <div className="dashboard-card customer-summary-card">
              <div className="customer-summary-icon">
                <Database size={22} />
              </div>

              <div className="customer-summary-content">
                <span>CUSTOMER COLUMN</span>

                <strong className="column-value">
                  {customerColumn || "Not detected"}
                </strong>

                <small>
                  Detected from your dataset
                </small>
              </div>
            </div>
          </div>

          {/* =================================================
              CUSTOMER LIST
          ================================================= */}

          <div className="dashboard-card customers-list-card">
            <div className="customers-list-header">
              <div>
                <div className="customers-list-title-row">
                  <div className="customers-list-heading-icon">
                    <UserPlus size={18} />
                  </div>

                  <div>
                    <h2>Customer List</h2>

                    <p>
                      Customers connected to your current
                      business dataset.
                    </p>
                  </div>
                </div>
              </div>

              {customers.length > 0 && (
                <div className="customers-list-actions">
                  {/* SEARCH */}

                  <div className="customers-search">
                    <Search size={17} />

                    <input
                      type="text"
                      name="customer-search"
                      id="customer-search"
                      placeholder="Search customers..."
                      value={search}
                      onChange={handleSearch}
                      autoComplete="off"
                    />

                    {search && (
                      <button
                        type="button"
                        className="clear-search-button"
                        onClick={() => {
                          setSearch("");
                          setCurrentPage(1);
                        }}
                        aria-label="Clear search"
                      >
                        ×
                      </button>
                    )}
                  </div>

                  {/* FILTER */}

                  <div className="customer-filter-wrapper">
                    <button
                      type="button"
                      className={`customer-filter-button ${
                        activeFilter !== "all"
                          ? "filter-active"
                          : ""
                      }`}
                      onClick={() =>
                        setFilterOpen(
                          (open) => !open
                        )
                      }
                      aria-expanded={filterOpen}
                    >
                      <SlidersHorizontal size={17} />

                      <span>
                        {activeFilterLabel}
                      </span>

                      <span className="filter-chevron">
                        {filterOpen ? "⌃" : "⌄"}
                      </span>
                    </button>

                    {filterOpen && (
                      <div className="customer-filter-menu">
                        <div className="filter-menu-header">
                          <div>
                            <strong>
                              Filter Customers
                            </strong>

                            <span>
                              Choose a customer segment
                            </span>
                          </div>
                        </div>

                        <div className="filter-options">
                          {filterOptions.map(
                            (option) => (
                              <button
                                type="button"
                                key={option.id}
                                className={`filter-option ${
                                  activeFilter ===
                                  option.id
                                    ? "selected"
                                    : ""
                                }`}
                                onClick={() =>
                                  handleFilterChange(
                                    option.id
                                  )
                                }
                              >
                                <div className="filter-option-content">
                                  <strong>
                                    {option.label}
                                  </strong>

                                  <span>
                                    {
                                      option.description
                                    }
                                  </span>
                                </div>

                                {activeFilter ===
                                  option.id && (
                                  <Check
                                    size={17}
                                  />
                                )}
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* ACTIVE FILTER INDICATOR */}

            {!loading &&
              customers.length > 0 &&
              (activeFilter !== "all" || search) && (
                <div className="active-filter-bar">
                  <div className="active-filter-info">
                    <SlidersHorizontal size={14} />

                    <span>
                      Showing{" "}
                      <strong>
                        {filteredCustomers.length}
                      </strong>{" "}
                      customer
                      {filteredCustomers.length !==
                      1
                        ? "s"
                        : ""}

                      {activeFilter !== "all" && (
                        <>
                          {" "}
                          in{" "}
                          <strong>
                            {activeFilterLabel}
                          </strong>
                        </>
                      )}

                      {search && (
                        <>
                          {" "}
                          matching{" "}
                          <strong>
                            "{search}"
                          </strong>
                        </>
                      )}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setActiveFilter("all");
                      setSearch("");
                      setCurrentPage(1);
                    }}
                  >
                    Clear all
                  </button>
                </div>
              )}

            {/* =================================================
                LOADING
            ================================================= */}

            {loading && (
              <div className="customers-empty-state customers-loading-state">
                <RefreshCw
                  size={30}
                  className="customer-refresh-spin"
                />

                <h3>Loading customers...</h3>

                <p>
                  Reading customer information from
                  your saved dataset.
                </p>
              </div>
            )}

            {/* =================================================
                EMPTY
            ================================================= */}

            {!loading &&
              !error &&
              customers.length === 0 && (
                <div className="customers-empty-state">
                  <div className="customers-empty-icon">
                    <Database size={28} />
                  </div>

                  <h3>No customers found</h3>

                  <p>
                    Add or upload business data with a
                    Customer Name column from the Upload
                    Data page to see customers here.
                  </p>
                </div>
              )}

            {/* =================================================
                NO MATCH
            ================================================= */}

            {!loading &&
              customers.length > 0 &&
              filteredCustomers.length === 0 && (
                <div className="customers-empty-state">
                  <div className="customers-empty-icon">
                    <Search size={28} />
                  </div>

                  <h3>
                    No customers match this filter
                  </h3>

                  <p>
                    Try another filter or clear the
                    search to see more customers.
                  </p>

                  <button
                    type="button"
                    className="empty-clear-button"
                    onClick={() => {
                      setActiveFilter("all");
                      setSearch("");
                      setCurrentPage(1);
                    }}
                  >
                    Clear Filters
                  </button>
                </div>
              )}

            {/* =================================================
                CUSTOMER ROWS
            ================================================= */}

            {!loading &&
              visibleCustomers.length > 0 && (
                <>
                  <div className="customer-list">
                    {visibleCustomers.map(
                      (customer, index) => (
                        <div
                          className="customer-row"
                          key={`${customer.name}-${index}`}
                        >
                          {/* TOP */}

                          <div className="customer-row-top">
                            <div className="customer-avatar">
                              {getInitial(
                                customer.name
                              )}
                            </div>

                            <div className="customer-info">
                              <strong>
                                {customer.name ||
                                  "Unknown Customer"}
                              </strong>

                              <span>
                                {customer.purchaseCount}{" "}
                                purchase
                                {customer.purchaseCount !==
                                1
                                  ? "s"
                                  : ""}

                                <span className="customer-meta-dot">
                                  •
                                </span>

                                {formatCurrency(
                                  customer.totalSpent
                                )}{" "}
                                total
                              </span>
                            </div>

                            <div
                              className={`customer-status ${
                                customer.hasPending
                                  ? "status-pending"
                                  : "status-paid"
                              }`}
                            >
                              {customer.hasPending
                                ? "Pending"
                                : "Paid"}
                            </div>
                          </div>

                          {/* FINANCIAL DETAILS */}

                          <div className="customer-financial-row">
                            <div className="customer-financial-item">
                              <span>Total</span>

                              <strong>
                                {formatCurrency(
                                  customer.totalSpent
                                )}
                              </strong>
                            </div>

                            <div className="customer-financial-item paid-financial">
                              <span>Paid</span>

                              <strong>
                                {formatCurrency(
                                  customer.totalPaid
                                )}
                              </strong>
                            </div>

                            <div className="customer-financial-item pending-financial">
                              <span>Pending</span>

                              <strong>
                                {formatCurrency(
                                  customer.totalPending
                                )}
                              </strong>
                            </div>
                          </div>

                          {/* PURCHASE HISTORY */}

                          {customer.purchases.length >
                            0 && (
                            <div className="customer-purchases">
                              <div className="purchase-section-label">
                                PURCHASE HISTORY
                              </div>

                              <div className="purchase-chip-list">
                                {customer.purchases.map(
                                  (
                                    purchase,
                                    purchaseIndex
                                  ) => (
                                    <div
                                      className={`purchase-chip ${
                                        purchase.status ===
                                        "Pending"
                                          ? "chip-pending"
                                          : "chip-paid"
                                      }`}
                                      key={`${customer.name}-${purchaseIndex}`}
                                    >
                                      <span className="purchase-chip-product">
                                        {purchase.product}

                                        {purchase.quantity !==
                                          undefined &&
                                          purchase.quantity !==
                                            null &&
                                          String(
                                            purchase.quantity
                                          ).trim() !==
                                            "" && (
                                            <>
                                              {" × "}
                                              {
                                                purchase.quantity
                                              }
                                            </>
                                          )}
                                      </span>

                                      <span className="purchase-chip-amount">
                                        {formatCurrency(
                                          purchase.amount
                                        )}
                                      </span>

                                      <span className="purchase-chip-status">
                                        {purchase.status}
                                      </span>
                                    </div>
                                  )
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    )}
                  </div>

                  {/* =================================================
                      PAGINATION
                  ================================================= */}

                  {totalPages > 1 && (
                    <div className="customers-pagination">
                      <div className="customers-pagination-info">
                        Showing{" "}
                        <strong>{pageStart}</strong>
                        {" – "}
                        <strong>{pageEnd}</strong>
                        {" of "}
                        <strong>
                          {filteredCustomers.length.toLocaleString()}
                        </strong>
                      </div>

                      <div className="customers-pagination-controls">
                        <button
                          type="button"
                          onClick={goToPreviousPage}
                          disabled={
                            safeCurrentPage === 1
                          }
                          aria-label="Previous page"
                        >
                          <ChevronLeft size={17} />
                        </button>

                        <span>
                          Page{" "}
                          <strong>
                            {safeCurrentPage}
                          </strong>
                          {" of "}
                          <strong>
                            {totalPages}
                          </strong>
                        </span>

                        <button
                          type="button"
                          onClick={goToNextPage}
                          disabled={
                            safeCurrentPage ===
                            totalPages
                          }
                          aria-label="Next page"
                        >
                          <ChevronRight size={17} />
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default Customers;