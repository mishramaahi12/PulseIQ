import { useEffect, useMemo, useState } from "react";

import {
  BarChart3,
  CalendarDays,
  Download,
  FileText,
  IndianRupee,
  Package,
  RefreshCw,
  TrendingUp,
  Users,
} from "lucide-react";

import Sidebar from "../components/dashboard/sidebar";
import Topbar from "../components/dashboard/topbar";

import "./reports.css";

function Reports() {
  const [data, setData] = useState({
    revenue: 0,
    orders: 0,
    customers: 0,
    source: "demo",
  });

  const [businessRows, setBusinessRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState("all");

  useEffect(() => {
    loadReportData();

    const handleDataUpdate = () => {
      loadReportData();
    };

    window.addEventListener(
      "pulseiq-data-updated",
      handleDataUpdate
    );

    return () => {
      window.removeEventListener(
        "pulseiq-data-updated",
        handleDataUpdate
      );
    };
  }, []);

  const loadReportData = async () => {
    setLoading(true);

    try {
      const savedData = localStorage.getItem(
        "pulseiq_business_data"
      );

      if (savedData) {
        const rows = JSON.parse(savedData);

        if (Array.isArray(rows) && rows.length > 0) {
          setBusinessRows(rows);

          const revenue = rows.reduce(
            (sum, row) =>
              sum + (Number(row?.totalAmount) || 0),
            0
          );

          const customers = new Set(
            rows
              .map((row) =>
                String(row?.customerName || "").trim()
              )
              .filter(Boolean)
          ).size;

          setData({
            revenue,
            orders: rows.length,
            customers,
            source: "actual",
          });

          setLoading(false);
          return;
        }
      }

      const response = await fetch(
        "http://127.0.0.1:8000/dashboard"
      );

      const result = await response.json();

      if (result?.source === "actual") {
        setData({
          revenue: Number(result.revenue || 0),
          orders: Number(result.orders || 0),
          customers: Number(result.customers || 0),
          source: "actual",
        });
      }
    } catch (error) {
      console.error("Reports data error:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    const amount = Number(value || 0);

    if (amount >= 10000000) {
      return `₹${(amount / 10000000).toFixed(2)}Cr`;
    }

    if (amount >= 100000) {
      return `₹${(amount / 100000).toFixed(2)}L`;
    }

    if (amount >= 1000) {
      return `₹${(amount / 1000).toFixed(1)}K`;
    }

    return `₹${amount.toLocaleString("en-IN")}`;
  };

  const filteredRows = useMemo(() => {
    if (!businessRows.length) {
      return [];
    }

    if (selectedPeriod === "all") {
      return businessRows;
    }

    const now = new Date();

    const days =
      selectedPeriod === "7days"
        ? 7
        : selectedPeriod === "30days"
        ? 30
        : 90;

    const startDate = new Date(now);
    startDate.setDate(now.getDate() - days);

    return businessRows.filter((row) => {
      const dateValue =
        row?.purchaseDate ||
        row?.date ||
        row?.orderDate;

      if (!dateValue) {
        return false;
      }

      const rowDate = new Date(dateValue);

      return (
        !Number.isNaN(rowDate.getTime()) &&
        rowDate >= startDate
      );
    });
  }, [businessRows, selectedPeriod]);

  const reportStats = useMemo(() => {
    const rows =
      businessRows.length > 0
        ? filteredRows
        : [];

    if (!rows.length) {
      return {
        revenue: data.revenue,
        orders: data.orders,
        customers: data.customers,
      };
    }

    const revenue = rows.reduce(
      (sum, row) =>
        sum + (Number(row?.totalAmount) || 0),
      0
    );

    const customers = new Set(
      rows
        .map((row) =>
          String(row?.customerName || "").trim()
        )
        .filter(Boolean)
    ).size;

    return {
      revenue,
      orders: rows.length,
      customers,
    };
  }, [businessRows, filteredRows, data]);

  const productReport = useMemo(() => {
    const map = new Map();

    filteredRows.forEach((row) => {
      const product =
        String(
          row?.product || "Unknown Product"
        ).trim() || "Unknown Product";

      const amount =
        Number(row?.totalAmount) || 0;

      const quantity =
        Number(row?.quantity) || 1;

      if (!map.has(product)) {
        map.set(product, {
          name: product,
          sales: 0,
          revenue: 0,
        });
      }

      const item = map.get(product);

      item.sales += quantity;
      item.revenue += amount;
    });

    return Array.from(map.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [filteredRows]);

  const paymentReport = useMemo(() => {
    return filteredRows.reduce(
      (result, row) => {
        const status = String(
          row?.paymentStatus || ""
        ).toLowerCase();

        const amount =
          Number(row?.totalAmount) || 0;

        if (status === "pending") {
          result.pendingCount += 1;
          result.pendingAmount += amount;
        } else {
          result.paidCount += 1;
          result.paidAmount += amount;
        }

        return result;
      },
      {
        paidCount: 0,
        pendingCount: 0,
        paidAmount: 0,
        pendingAmount: 0,
      }
    );
  }, [filteredRows]);

  const downloadPDF = () => {
    window.print();
  };

  const periodLabel =
    selectedPeriod === "all"
      ? "All Time"
      : selectedPeriod === "7days"
      ? "Last 7 Days"
      : selectedPeriod === "30days"
      ? "Last 30 Days"
      : "Last 90 Days";

  const reportCards = [
    {
      title: "SALES REPORT",
      value: reportStats.orders.toLocaleString(),
      description: "Total orders recorded",
      icon: BarChart3,
    },
    {
      title: "REVENUE REPORT",
      value: formatCurrency(reportStats.revenue),
      description: "Total business revenue",
      icon: IndianRupee,
    },
    {
      title: "CUSTOMER REPORT",
      value: reportStats.customers.toLocaleString(),
      description: "Unique customers",
      icon: Users,
    },
    {
      title: "PAYMENT REPORT",
      value: formatCurrency(paymentReport.paidAmount),
      description: "Successfully collected",
      icon: TrendingUp,
    },
  ];

  return (
    <div className="dashboard-shell reports-shell">
      <Sidebar />

      <div className="dashboard-main">
        <Topbar />

        <main className="dashboard-content reports-page">

          {/* =========================
              HEADER
          ========================= */}

          <section className="reports-header">
            <div className="reports-header-content">

              <div className="reports-eyebrow">
                BUSINESS REPORTS
              </div>

              <h1 className="reports-title">
                Reports &amp; Insights
              </h1>

              <p className="reports-description">
                Generate clear business reports from
                your uploaded PulseIQ data.
              </p>

            </div>

            <div className="reports-header-actions">

              <button
                type="button"
                className="reports-refresh-button"
                onClick={loadReportData}
                disabled={loading}
              >
                <RefreshCw
                  size={17}
                  className={
                    loading ? "reports-spin" : ""
                  }
                />
                Refresh
              </button>

              <button
                type="button"
                className="reports-download-button"
                onClick={downloadPDF}
              >
                <Download size={17} />
                Download PDF
              </button>

            </div>
          </section>

          {/* =========================
              PERIOD
          ========================= */}

          <section className="reports-toolbar dashboard-card">

            <div className="reports-toolbar-left">

              <div className="reports-toolbar-icon">
                <CalendarDays size={19} />
              </div>

              <div>
                <strong>Report Period</strong>

                <span>
                  Showing data for {periodLabel}
                </span>
              </div>

            </div>

            <div className="reports-period-buttons">

              {[
                ["all", "All Time"],
                ["7days", "7 Days"],
                ["30days", "30 Days"],
                ["90days", "90 Days"],
              ].map(([id, label]) => (
                <button
                  type="button"
                  key={id}
                  className={
                    selectedPeriod === id
                      ? "active"
                      : ""
                  }
                  onClick={() =>
                    setSelectedPeriod(id)
                  }
                >
                  {label}
                </button>
              ))}

            </div>

          </section>

          {/* =========================
              STAT CARDS
          ========================= */}

          <section className="reports-stats-grid">

            {reportCards.map((card) => {
              const Icon = card.icon;

              return (
                <div
                  className="dashboard-card report-stat-card"
                  key={card.title}
                >

                  <div className="report-stat-top">

                    <div className="report-stat-icon">
                      <Icon size={21} />
                    </div>

                    <span>
                      {card.title}
                    </span>

                  </div>

                  <strong>
                    {loading ? "..." : card.value}
                  </strong>

                  <small>
                    {card.description}
                  </small>

                </div>
              );
            })}

          </section>

          {/* =========================
              OVERVIEW + PAYMENTS
          ========================= */}

          <section className="reports-main-grid">

            <div className="dashboard-card report-overview-card">

              <div className="report-section-heading">

                <div>
                  <span className="report-section-label">
                    OVERVIEW
                  </span>

                  <h2>
                    Business Performance
                  </h2>

                  <p>
                    A quick summary of your current
                    business performance.
                  </p>
                </div>

                <FileText size={21} />

              </div>

              <div className="performance-list">

                <div className="performance-item">

                  <div className="performance-label">
                    <span>Total Revenue</span>

                    <strong>
                      {formatCurrency(
                        reportStats.revenue
                      )}
                    </strong>
                  </div>

                  <div className="performance-track">
                    <div
                      className="performance-fill"
                      style={{ width: "100%" }}
                    />
                  </div>

                </div>

                <div className="performance-item">

                  <div className="performance-label">
                    <span>Paid Amount</span>

                    <strong>
                      {formatCurrency(
                        paymentReport.paidAmount
                      )}
                    </strong>
                  </div>

                  <div className="performance-track">

                    <div
                      className="performance-fill paid-fill"
                      style={{
                        width:
                          reportStats.revenue > 0
                            ? `${Math.min(
                                100,
                                (paymentReport.paidAmount /
                                  reportStats.revenue) *
                                  100
                              )}%`
                            : "0%",
                      }}
                    />

                  </div>

                </div>

                <div className="performance-item">

                  <div className="performance-label">
                    <span>Pending Amount</span>

                    <strong>
                      {formatCurrency(
                        paymentReport.pendingAmount
                      )}
                    </strong>
                  </div>

                  <div className="performance-track">

                    <div
                      className="performance-fill pending-fill"
                      style={{
                        width:
                          reportStats.revenue > 0
                            ? `${Math.min(
                                100,
                                (paymentReport.pendingAmount /
                                  reportStats.revenue) *
                                  100
                              )}%`
                            : "0%",
                      }}
                    />

                  </div>

                </div>

              </div>

            </div>

            <div className="dashboard-card report-payment-card">

              <div className="report-section-heading">

                <div>
                  <span className="report-section-label">
                    PAYMENTS
                  </span>

                  <h2>
                    Payment Status
                  </h2>

                  <p>
                    Collection and outstanding
                    payment overview.
                  </p>
                </div>

                <IndianRupee size={21} />

              </div>

              <div className="payment-status-grid">

                <div className="payment-box">

                  <span>PAID</span>

                  <strong>
                    {paymentReport.paidCount.toLocaleString()}
                  </strong>

                  <small>
                    {formatCurrency(
                      paymentReport.paidAmount
                    )}
                  </small>

                </div>

                <div className="payment-box">

                  <span>PENDING</span>

                  <strong>
                    {paymentReport.pendingCount.toLocaleString()}
                  </strong>

                  <small>
                    {formatCurrency(
                      paymentReport.pendingAmount
                    )}
                  </small>

                </div>

              </div>

            </div>

          </section>

          {/* =========================
              PRODUCTS
          ========================= */}

          <section className="dashboard-card product-report-card">

            <div className="report-section-heading">

              <div>
                <span className="report-section-label">
                  PRODUCT PERFORMANCE
                </span>

                <h2>
                  Top Performing Products
                </h2>

                <p>
                  Products generating the highest
                  revenue in the selected period.
                </p>
              </div>

              <Package size={21} />

            </div>

            {productReport.length > 0 ? (

              <div className="product-report-list">

                {productReport.map(
                  (product, index) => (
                    <div
                      className="product-report-row"
                      key={product.name}
                    >

                      <div className="product-rank">
                        #{index + 1}
                      </div>

                      <div className="product-report-info">

                        <strong>
                          {product.name}
                        </strong>

                        <span>
                          {product.sales.toLocaleString()}{" "}
                          units sold
                        </span>

                      </div>

                      <div className="product-report-revenue">
                        {formatCurrency(
                          product.revenue
                        )}
                      </div>

                    </div>
                  )
                )}

              </div>

            ) : (

              <div className="report-no-data">

                <Package size={28} />

                <strong>
                  No product data available
                </strong>

                <span>
                  Upload business data to generate
                  product performance reports.
                </span>

              </div>

            )}

          </section>

          {/* =========================
              FOOTER
          ========================= */}

          <div className="report-source-footer">

            <span>
              ●{" "}
              {data.source === "actual"
                ? "Reports are based on your uploaded business data."
                : "Reports are currently showing available dashboard data."}
            </span>

            <span>
              PulseIQ Business Intelligence
            </span>

          </div>

        </main>
      </div>
    </div>
  );
}

export default Reports;