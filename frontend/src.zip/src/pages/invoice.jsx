import { useEffect, useMemo, useState } from "react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  FileText,
  Plus,
  Trash2,
  User,
  CheckCircle,
  Download,
} from "lucide-react";

import Sidebar from "../components/dashboard/sidebar";
import Topbar from "../components/dashboard/topbar";

import "./invoice.css";

/* =========================================================
   HELPERS
   ========================================================= */

const createEmptyItem = () => ({
  product: "",
  quantity: 1,
  unitPrice: 0,
});

const todayISO = () => {
  return new Date().toISOString().split("T")[0];
};

const getNextInvoiceId = () => {
  const current = Number(
    localStorage.getItem("pulseiq_invoice_counter") || "0"
  );

  const next = current + 1;

  localStorage.setItem("pulseiq_invoice_counter", String(next));

  return `INV-${String(next).padStart(4, "0")}`;
};

const loadBusinessRows = () => {
  try {
    const raw = localStorage.getItem("pulseiq_business_data");

    if (!raw) return [];

    const parsed = JSON.parse(raw);

    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const loadCustomerDirectory = () => {
  try {
    const raw = localStorage.getItem("pulseiq_customer_directory");

    if (!raw) return {};

    const parsed = JSON.parse(raw);

    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
};

const loadInvoices = () => {
  try {
    const raw = localStorage.getItem("pulseiq_invoices");

    if (!raw) return [];

    const parsed = JSON.parse(raw);

    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

/* =========================================================
   COMPONENT
   ========================================================= */

function Invoice() {
  const [businessRows, setBusinessRows] = useState([]);
  const [customerDirectory, setCustomerDirectory] = useState({});
  const [existingCustomers, setExistingCustomers] = useState([]);

  const [customerMode, setCustomerMode] = useState("existing");
  const [selectedCustomer, setSelectedCustomer] = useState("");

  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");

  const [invoiceId, setInvoiceId] = useState("");
  const [invoiceDate, setInvoiceDate] = useState(todayISO());
  const [paymentStatus, setPaymentStatus] = useState("Pending");

  const [discount, setDiscount] = useState(0);
  const [taxRate, setTaxRate] = useState(18);

  const [items, setItems] = useState([createEmptyItem()]);

  const [invoices, setInvoices] = useState([]);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  /* =========================================================
     LOAD DATA
     ========================================================= */

  useEffect(() => {
  const loadAllCustomerData = () => {
    const rows = loadBusinessRows();
    const directory = loadCustomerDirectory();
    const savedInvoices = loadInvoices();

    setBusinessRows(rows);
    setCustomerDirectory(directory);
    setInvoices(savedInvoices);

    const namesFromRows = rows
      .map((row) => {
        return (
          row.customerName ||
          row.customer ||
          row.customer_name ||
          row.name ||
          row.Customer ||
          row["Customer Name"] ||
          ""
        );
      })
      .map((name) => String(name).trim())
      .filter(Boolean);

    const namesFromDirectory = Object.keys(directory)
      .map((name) => String(name).trim())
      .filter(Boolean);

    const namesFromInvoices = savedInvoices
      .map((invoice) => invoice.customerName || "")
      .map((name) => String(name).trim())
      .filter(Boolean);

    const uniqueNames = Array.from(
      new Set([
        ...namesFromDirectory,
        ...namesFromRows,
        ...namesFromInvoices,
      ])
    ).sort((a, b) => a.localeCompare(b));

    setExistingCustomers(uniqueNames);
  };

  loadAllCustomerData();

  if (!localStorage.getItem("pulseiq_invoice_counter")) {
    localStorage.setItem("pulseiq_invoice_counter", "0");
  }

  setInvoiceId(getNextInvoiceId());

  const handleDataUpdate = () => {
    loadAllCustomerData();
  };

  window.addEventListener(
    "pulseiq-data-updated",
    handleDataUpdate
  );

  window.addEventListener(
    "pulseiq-dataset-updated",
    handleDataUpdate
  );

  window.addEventListener("storage", handleDataUpdate);

  return () => {
    window.removeEventListener(
      "pulseiq-data-updated",
      handleDataUpdate
    );

    window.removeEventListener(
      "pulseiq-dataset-updated",
      handleDataUpdate
    );

    window.removeEventListener("storage", handleDataUpdate);
  };
}, []);

  /* =========================================================
     CUSTOMER SELECTION
     ========================================================= */

  useEffect(() => {
  if (customerMode !== "existing" || !selectedCustomer) {
    return;
  }

  const directoryData = customerDirectory[selectedCustomer];

  if (directoryData) {
    setCustomerName(selectedCustomer);
    setCustomerEmail(directoryData.email || "");
    setCustomerPhone(directoryData.phone || "");
    setCustomerAddress(directoryData.address || "");
    return;
  }

  const matchingRow = businessRows.find((row) => {
    const name =
      row.customerName ||
      row.customer ||
      row.customer_name ||
      row.name ||
      row.Customer ||
      row["Customer Name"];

    return String(name || "").trim() === selectedCustomer;
  });

  if (matchingRow) {
    setCustomerName(selectedCustomer);

    setCustomerEmail(
      matchingRow.email ||
        matchingRow.customerEmail ||
        matchingRow.customer_email ||
        matchingRow["Customer Email"] ||
        ""
    );

    setCustomerPhone(
      matchingRow.phone ||
        matchingRow.customerPhone ||
        matchingRow.customer_phone ||
        matchingRow["Customer Phone"] ||
        ""
    );

    setCustomerAddress(
      matchingRow.address ||
        matchingRow.customerAddress ||
        matchingRow.customer_address ||
        matchingRow["Customer Address"] ||
        ""
    );
  }
}, [
  selectedCustomer,
  customerMode,
  customerDirectory,
  businessRows,
]);

  /* =========================================================
     ITEM HANDLERS
     ========================================================= */

  const updateItem = (index, field, value) => {
    setItems((current) =>
      current.map((item, itemIndex) => {
        if (itemIndex !== index) return item;

        return {
          ...item,
          [field]: value,
        };
      })
    );
  };

  const addItem = () => {
    setItems((current) => [...current, createEmptyItem()]);
  };

  const removeItem = (index) => {
    setItems((current) => {
      if (current.length === 1) {
        return [createEmptyItem()];
      }

      return current.filter((_, itemIndex) => itemIndex !== index);
    });
  };

  /* =========================================================
     CALCULATIONS
     ========================================================= */

  const subtotal = useMemo(() => {
    return items.reduce((total, item) => {
      const quantity = Number(item.quantity) || 0;
      const unitPrice = Number(item.unitPrice) || 0;

      return total + quantity * unitPrice;
    }, 0);
  }, [items]);

  const discountAmount = useMemo(() => {
    const value = Number(discount) || 0;

    return Math.min(Math.max(value, 0), subtotal);
  }, [discount, subtotal]);

  const taxableAmount = useMemo(() => {
    return Math.max(subtotal - discountAmount, 0);
  }, [subtotal, discountAmount]);

  const taxAmount = useMemo(() => {
    const rate = Number(taxRate) || 0;

    return taxableAmount * (rate / 100);
  }, [taxableAmount, taxRate]);

  const grandTotal = useMemo(() => {
    return taxableAmount + taxAmount;
  }, [taxableAmount, taxAmount]);

  /* =========================================================
     FORMATTERS
     ========================================================= */

  const formatCurrency = (value) => {
    return `₹${Number(value || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  const formatPDFCurrency = (value) => {
    return `Rs. ${Number(value || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  const formatDate = (date) => {
    if (!date) return "";

    const parsed = new Date(`${date}T00:00:00`);

    if (Number.isNaN(parsed.getTime())) return date;

    return parsed.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  /* =========================================================
     SAVE CUSTOMER
     ========================================================= */

  const saveCustomerToDirectory = () => {
    const currentDirectory = loadCustomerDirectory();

    currentDirectory[customerName.trim()] = {
      email: customerEmail.trim(),
      phone: customerPhone.trim(),
      address: customerAddress.trim(),
      updatedAt: new Date().toISOString(),
    };

    localStorage.setItem(
      "pulseiq_customer_directory",
      JSON.stringify(currentDirectory)
    );

    setCustomerDirectory(currentDirectory);

    const updatedCustomers = Array.from(
      new Set([
        ...existingCustomers,
        customerName.trim(),
      ])
    ).sort((a, b) => a.localeCompare(b));

    setExistingCustomers(updatedCustomers);
  };

  /* =========================================================
     SAVE BUSINESS DATA
     ========================================================= */

  const saveBusinessRow = () => {
    const currentRows = loadBusinessRows();

    const row = {
      customer: customerName.trim(),
      customer_name: customerName.trim(),
      email: customerEmail.trim(),
      phone: customerPhone.trim(),
      address: customerAddress.trim(),

      invoice_id: invoiceId,
      invoice_date: invoiceDate,
      payment_status: paymentStatus,

      product:
        items
          .filter((item) => item.product.trim())
          .map((item) => item.product.trim())
          .join(", "),

      quantity: items.reduce(
        (sum, item) => sum + (Number(item.quantity) || 0),
        0
      ),

      subtotal,
      discount: discountAmount,
      tax: taxAmount,
      tax_rate: Number(taxRate) || 0,
      revenue: grandTotal,
      total: grandTotal,

      source: "invoice",
      created_at: new Date().toISOString(),
    };

    currentRows.push(row);

    localStorage.setItem(
      "pulseiq_business_data",
      JSON.stringify(currentRows)
    );

    setBusinessRows(currentRows);

    localStorage.setItem(
      "pulseiq_data_version",
      String(Date.now())
    );

    window.dispatchEvent(new Event("pulseiq-data-updated"));
  };

  /* =========================================================
     RESET FORM
     ========================================================= */

  const resetForm = () => {
    setCustomerMode("existing");
    setSelectedCustomer("");

    setCustomerName("");
    setCustomerEmail("");
    setCustomerPhone("");
    setCustomerAddress("");

    setInvoiceId(getNextInvoiceId());
    setInvoiceDate(todayISO());

    setPaymentStatus("Pending");

    setDiscount(0);
    setTaxRate(18);

    setItems([createEmptyItem()]);

    setError("");
  };

  /* =========================================================
     GENERATE PDF
     ========================================================= */

  const generatePDF = (invoice) => {
    const doc = new jsPDF("p", "mm", "a4");

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    const margin = 16;

    /* =======================================================
       TOP ACCENT
       ======================================================= */

    doc.setFillColor(37, 99, 235);
    doc.rect(0, 0, pageWidth, 5, "F");

    /* =======================================================
       BRAND
       ======================================================= */

    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);

    doc.text("Pulse", margin, 22);

    const pulseWidth = doc.getTextWidth("Pulse");

    doc.setTextColor(37, 99, 235);
    doc.text("IQ", margin + pulseWidth, 22);

    doc.setTextColor(100, 116, 139);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);

    doc.text(
      "Business Intelligence for Smarter Decisions",
      margin,
      28
    );

    /* =======================================================
       INVOICE TITLE
       ======================================================= */

    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(29);

    doc.text("INVOICE", pageWidth - margin, 22, {
      align: "right",
    });

    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");

    doc.setTextColor(100, 116, 139);

    doc.text(
      `Invoice # ${invoice.invoiceId}`,
      pageWidth - margin,
      29,
      {
        align: "right",
      }
    );

    doc.text(
      `Date: ${formatDate(invoice.invoiceDate)}`,
      pageWidth - margin,
      35,
      {
        align: "right",
      }
    );

    /* =======================================================
       BILL TO + PAYMENT STATUS
       ======================================================= */

    const infoY = 46;
    const infoHeight = 39;

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);

    doc.roundedRect(
      margin,
      infoY,
      pageWidth - margin * 2,
      infoHeight,
      3,
      3,
      "FD"
    );

    /* Vertical separator */

    doc.setDrawColor(226, 232, 240);

    const paymentColumnWidth = 45;

    const separatorX =
      pageWidth - margin - paymentColumnWidth;

    doc.line(
      separatorX,
      infoY + 6,
      separatorX,
      infoY + infoHeight - 6
    );

    /* BILL TO */

    doc.setTextColor(37, 99, 235);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);

    doc.text("BILL TO", margin + 7, infoY + 9);

    doc.setTextColor(15, 23, 42);
    doc.setFontSize(12);

    doc.text(
      String(invoice.customerName || "").slice(0, 35),
      margin + 7,
      infoY + 18
    );

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);

    let customerY = infoY + 25;

    if (invoice.customerEmail) {
      const emailLines = doc.splitTextToSize(
        String(invoice.customerEmail),
        78
      );

      doc.text(emailLines, margin + 7, customerY);

      customerY += emailLines.length * 4.2;
    }

    if (invoice.customerPhone) {
      doc.text(
        String(invoice.customerPhone),
        margin + 7,
        customerY
      );

      customerY += 4.2;
    }

    if (invoice.customerAddress) {
      const addressLines = doc.splitTextToSize(
        String(invoice.customerAddress),
        78
      );

      doc.text(addressLines, margin + 7, customerY);
    }

    /* PAYMENT STATUS */

    const paymentX = separatorX + 5;

    doc.setTextColor(100, 116, 139);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);

    doc.text("PAYMENT", paymentX, infoY + 10);

    doc.text("STATUS", paymentX, infoY + 14.5);

    const isPaid =
      String(invoice.paymentStatus).toLowerCase() === "paid";

    if (isPaid) {
      doc.setFillColor(220, 252, 231);
      doc.setTextColor(22, 101, 52);
    } else {
      doc.setFillColor(254, 249, 195);
      doc.setTextColor(133, 77, 14);
    }

    doc.roundedRect(
      paymentX,
      infoY + 20,
      34,
      11,
      2.5,
      2.5,
      "F"
    );

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);

    doc.text(
      isPaid ? "PAID" : "PENDING",
      paymentX + 17,
      infoY + 27,
      {
        align: "center",
      }
    );

    /* =======================================================
       ITEMS HEADING
       ======================================================= */

    let tableY = infoY + infoHeight + 14;

    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);

    doc.text("Invoice Details", margin, tableY);

    doc.setDrawColor(226, 232, 240);

    doc.line(
      margin,
      tableY + 4,
      pageWidth - margin,
      tableY + 4
    );

    /* =======================================================
       ITEMS TABLE
       ======================================================= */

    const tableRows = invoice.items.map((item) => {
      const quantity = Number(item.quantity) || 0;
      const unitPrice = Number(item.unitPrice) || 0;
      const amount = quantity * unitPrice;

      return [
        item.product || "Item",
        String(quantity),
        formatPDFCurrency(unitPrice),
        formatPDFCurrency(amount),
      ];
    });

    autoTable(doc, {
      startY: tableY + 9,
      margin: {
        left: margin,
        right: margin,
      },

      head: [
        [
          "DESCRIPTION",
          "QTY",
          "UNIT PRICE",
          "AMOUNT",
        ],
      ],

      body: tableRows,

      theme: "plain",

      styles: {
        font: "helvetica",
        fontSize: 9,
        cellPadding: 4,
        textColor: [51, 65, 85],
        lineColor: [226, 232, 240],
        lineWidth: 0.2,
      },

      headStyles: {
        fillColor: [15, 23, 42],
        textColor: [255, 255, 255],
        fontStyle: "bold",
        fontSize: 8,
        cellPadding: 4,
      },

      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },

      columnStyles: {
        0: {
          cellWidth: "auto",
        },
        1: {
          halign: "center",
          cellWidth: 20,
        },
        2: {
          halign: "right",
          cellWidth: 38,
        },
        3: {
          halign: "right",
          cellWidth: 40,
        },
      },
    });

    /* =======================================================
       TOTALS
       ======================================================= */

    let finalY =
      doc.lastAutoTable?.finalY || tableY + 45;

    finalY += 10;

    const totalsWidth = 78;
    const totalsX = pageWidth - margin - totalsWidth;

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);

    doc.roundedRect(
      totalsX,
      finalY,
      totalsWidth,
      46,
      3,
      3,
      "FD"
    );

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);

    doc.text("Subtotal", totalsX + 7, finalY + 9);

    doc.text(
      formatPDFCurrency(invoice.subtotal),
      totalsX + totalsWidth - 7,
      finalY + 9,
      { align: "right" }
    );

    doc.text("Discount", totalsX + 7, finalY + 17);

    doc.text(
      `- ${formatPDFCurrency(invoice.discountAmount)}`,
      totalsX + totalsWidth - 7,
      finalY + 17,
      { align: "right" }
    );

    doc.text(
      `Tax (${Number(invoice.taxRate || 0)}%)`,
      totalsX + 7,
      finalY + 25
    );

    doc.text(
      formatPDFCurrency(invoice.taxAmount),
      totalsX + totalsWidth - 7,
      finalY + 25,
      { align: "right" }
    );

    doc.setDrawColor(203, 213, 225);

    doc.line(
      totalsX + 7,
      finalY + 29,
      totalsX + totalsWidth - 7,
      finalY + 29
    );

    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);

    doc.text("TOTAL", totalsX + 7, finalY + 39);

    doc.setTextColor(37, 99, 235);
    doc.setFontSize(14);

    doc.text(
      formatPDFCurrency(invoice.grandTotal),
      totalsX + totalsWidth - 7,
      finalY + 39,
      { align: "right" }
    );

    /* =======================================================
       PAYMENT SUMMARY
       ======================================================= */

    const summaryY = finalY + 57;

    doc.setFillColor(239, 246, 255);
    doc.setDrawColor(191, 219, 254);

    doc.roundedRect(
      margin,
      summaryY,
      pageWidth - margin * 2,
      23,
      3,
      3,
      "FD"
    );

    doc.setTextColor(30, 64, 175);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);

    doc.text(
      "PAYMENT SUMMARY",
      margin + 7,
      summaryY + 8
    );

    doc.setTextColor(51, 65, 85);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);

    doc.text(
      `Status: ${invoice.paymentStatus}`,
      margin + 7,
      summaryY + 15
    );

    doc.text(
      `Amount Due: ${formatPDFCurrency(invoice.grandTotal)}`,
      pageWidth - margin - 7,
      summaryY + 15,
      {
        align: "right",
      }
    );

    /* =======================================================
       THANK YOU
       ======================================================= */

    const thankY = summaryY + 32;

    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);

    doc.text(
      "Thank you for your business.",
      margin,
      thankY
    );

    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);

    doc.text(
      "Generated by PulseIQ Business Intelligence",
      margin,
      thankY + 6
    );

    /* =======================================================
       FOOTER
       ======================================================= */

    doc.setDrawColor(226, 232, 240);

    doc.line(
      margin,
      pageHeight - 18,
      pageWidth - margin,
      pageHeight - 18
    );

    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);

    doc.text(
      "PulseIQ — Business Intelligence for Smarter Decisions",
      margin,
      pageHeight - 10
    );

    doc.text(
      `Page 1 of 1`,
      pageWidth - margin,
      pageHeight - 10,
      {
        align: "right",
      }
    );

    /* =======================================================
       SAVE
       ======================================================= */

    const safeCustomerName = String(
      invoice.customerName || "Customer"
    )
      .replace(/[^a-z0-9]/gi, "_")
      .replace(/_+/g, "_");

    doc.save(
      `PulseIQ_Invoice_${invoice.invoiceId}_${safeCustomerName}.pdf`
    );
  };

  /* =========================================================
     GENERATE INVOICE
     ========================================================= */

  const handleGenerateInvoice = async () => {
    setError("");
    setSuccess("");

    const cleanCustomerName = customerName.trim();

    if (!cleanCustomerName) {
      setError("Please enter or select a customer.");
      return;
    }

    const validItems = items.filter((item) => {
      return (
        item.product.trim() &&
        Number(item.quantity) > 0 &&
        Number(item.unitPrice) >= 0
      );
    });

    if (validItems.length === 0) {
      setError(
        "Please add at least one valid invoice item."
      );
      return;
    }

    try {
      setIsGenerating(true);

      const invoice = {
        invoiceId,
        invoiceDate,

        customerName: cleanCustomerName,
        customerEmail: customerEmail.trim(),
        customerPhone: customerPhone.trim(),
        customerAddress: customerAddress.trim(),

        paymentStatus,

        items: validItems.map((item) => ({
          product: item.product.trim(),
          quantity: Number(item.quantity) || 0,
          unitPrice: Number(item.unitPrice) || 0,
        })),

        subtotal,
        discountAmount,
        taxableAmount,
        taxRate: Number(taxRate) || 0,
        taxAmount,
        grandTotal,

        createdAt: new Date().toISOString(),
      };

      /* Save customer */

      saveCustomerToDirectory();

      /* Save invoice */

      const currentInvoices = loadInvoices();

      const updatedInvoices = [
        ...currentInvoices,
        invoice,
      ];

      localStorage.setItem(
        "pulseiq_invoices",
        JSON.stringify(updatedInvoices)
      );

      setInvoices(updatedInvoices);

      /* Save business row */

      saveBusinessRow();

      /* Generate PDF */

      generatePDF(invoice);

      setSuccess(
        `Invoice ${invoice.invoiceId} generated successfully.`
      );

      /* Reset after successful generation */

      setTimeout(() => {
        setInvoiceId(getNextInvoiceId());
        setInvoiceDate(todayISO());

        setSelectedCustomer("");
        setCustomerName("");
        setCustomerEmail("");
        setCustomerPhone("");
        setCustomerAddress("");

        setItems([createEmptyItem()]);

        setDiscount(0);
        setTaxRate(18);
        setPaymentStatus("Pending");
      }, 300);
    } catch (err) {
      console.error("Invoice generation error:", err);

      setError(
        "Something went wrong while generating the invoice."
      );
    } finally {
      setIsGenerating(false);
    }
  };

  /* =========================================================
     RENDER
     ========================================================= */

  return (
    <div className="dashboard-layout">
      <Sidebar />

      <main className="dashboard-main">
        <Topbar />

        <div className="invoice-page">
          {/* =================================================
              HEADER
              ================================================= */}

          <div className="page-heading">
            <div>
              <h1>Create Invoice</h1>

              <p>
                Create professional invoices for your customers
                and download them instantly as PDF.
              </p>
            </div>

            <div className="invoice-id-badge">
              <FileText size={15} />
              {invoiceId}
            </div>
          </div>

          {/* =================================================
              ALERTS
              ================================================= */}

          {error && (
            <div className="invoice-alert invoice-error">
              <Trash2 size={17} />
              {error}
            </div>
          )}

          {success && (
            <div className="invoice-alert invoice-success">
              <CheckCircle size={17} />
              {success}
            </div>
          )}

          {/* =================================================
              CUSTOMER SECTION
              ================================================= */}

          <section className="invoice-section">
            <div className="invoice-section-header">
              <div className="invoice-step">01</div>

              <div>
                <h2>Customer Details</h2>

                <p>
                  Select an existing customer or create a new
                  customer for this invoice.
                </p>
              </div>
            </div>

            {/* CUSTOMER MODE */}

            <div className="customer-mode-toggle">
              <button
                type="button"
                className={
                  customerMode === "existing"
                    ? "active"
                    : ""
                }
                onClick={() => {
                  setCustomerMode("existing");
                  setSelectedCustomer("");
                  setCustomerName("");
                  setCustomerEmail("");
                  setCustomerPhone("");
                  setCustomerAddress("");
                }}
              >
                <User size={15} />
                Existing Customer
              </button>

              <button
                type="button"
                className={
                  customerMode === "new" ? "active" : ""
                }
                onClick={() => {
                  setCustomerMode("new");
                  setSelectedCustomer("");
                  setCustomerName("");
                  setCustomerEmail("");
                  setCustomerPhone("");
                  setCustomerAddress("");
                }}
              >
                <Plus size={15} />
                New Customer
              </button>
            </div>

            {/* EXISTING CUSTOMER */}

            {customerMode === "existing" && (
              <div className="invoice-field">
                <label>Select Customer</label>

                <select
                  value={selectedCustomer}
                  onChange={(event) => {
                    setSelectedCustomer(event.target.value);
                  }}
                >
                  <option value="">
                    Select an existing customer
                  </option>

                  {existingCustomers.map((customer) => (
                    <option
                      key={customer}
                      value={customer}
                    >
                      {customer}
                    </option>
                  ))}
                </select>

                <span className="invoice-hint">
                  Existing customer details will be filled
                  automatically.
                </span>
              </div>
            )}

            {/* CUSTOMER FIELDS */}

            <div className="invoice-grid-3">
              <div className="invoice-field">
                <label>Customer Name *</label>

                <input
                  type="text"
                  value={customerName}
                  onChange={(event) =>
                    setCustomerName(event.target.value)
                  }
                  placeholder="e.g. Rahul Sharma"
                />
              </div>

              <div className="invoice-field">
                <label>Email</label>

                <input
                  type="email"
                  value={customerEmail}
                  onChange={(event) =>
                    setCustomerEmail(event.target.value)
                  }
                  placeholder="customer@email.com"
                />
              </div>

              <div className="invoice-field">
                <label>Phone</label>

                <input
                  type="text"
                  value={customerPhone}
                  onChange={(event) =>
                    setCustomerPhone(event.target.value)
                  }
                  placeholder="+91 98765 43210"
                />
              </div>
            </div>

            <div className="invoice-field">
              <label>Address</label>

              <input
                type="text"
                value={customerAddress}
                onChange={(event) =>
                  setCustomerAddress(event.target.value)
                }
                placeholder="Customer billing address"
              />
            </div>
          </section>

          {/* =================================================
              INVOICE DETAILS
              ================================================= */}

          <section className="invoice-section">
            <div className="invoice-section-header">
              <div className="invoice-step">02</div>

              <div>
                <h2>Invoice Details</h2>

                <p>
                  Set the invoice date, payment status, discount
                  and tax information.
                </p>
              </div>
            </div>

            <div className="invoice-grid-3">
              <div className="invoice-field">
                <label>Invoice Number</label>

                <input
                  type="text"
                  value={invoiceId}
                  readOnly
                />
              </div>

              <div className="invoice-field">
                <label>Invoice Date</label>

                <input
                  type="date"
                  value={invoiceDate}
                  onChange={(event) =>
                    setInvoiceDate(event.target.value)
                  }
                />
              </div>

              <div className="invoice-field">
                <label>Payment Status</label>

                <select
                  value={paymentStatus}
                  onChange={(event) =>
                    setPaymentStatus(event.target.value)
                  }
                >
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
            </div>

            <div className="invoice-grid-3">
              <div className="invoice-field">
                <label>Discount</label>

                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={discount}
                  onChange={(event) =>
                    setDiscount(event.target.value)
                  }
                  placeholder="0"
                />
              </div>

              <div className="invoice-field">
                <label>Tax Rate (%)</label>

                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={taxRate}
                  onChange={(event) =>
                    setTaxRate(event.target.value)
                  }
                />
              </div>

              <div className="invoice-field">
                <label>Taxable Amount</label>

                <input
                  type="text"
                  value={formatCurrency(taxableAmount)}
                  readOnly
                />
              </div>
            </div>
          </section>

          {/* =================================================
              ITEMS SECTION
              ================================================= */}

          <section className="invoice-section">
            <div className="invoice-section-header">
              <div className="invoice-step">03</div>

              <div>
                <h2>Invoice Items</h2>

                <p>
                  Add products or services with quantity and
                  pricing.
                </p>
              </div>
            </div>

            <div className="invoice-items-table">
              {/* TABLE HEADER */}

              <div className="invoice-items-head">
                <span>Product / Service</span>
                <span>Quantity</span>
                <span>Unit Price</span>
                <span>Amount</span>
                <span></span>
              </div>

              {/* ITEMS */}

              {items.map((item, index) => {
                const quantity =
                  Number(item.quantity) || 0;

                const unitPrice =
                  Number(item.unitPrice) || 0;

                const amount = quantity * unitPrice;

                return (
                  <div
                    className="invoice-items-row"
                    key={index}
                  >
                    <input
                      type="text"
                      value={item.product}
                      onChange={(event) =>
                        updateItem(
                          index,
                          "product",
                          event.target.value
                        )
                      }
                      placeholder="Product or service"
                    />

                    <input
                      type="number"
                      min="1"
                      step="1"
                      value={item.quantity}
                      onChange={(event) =>
                        updateItem(
                          index,
                          "quantity",
                          event.target.value
                        )
                      }
                      placeholder="1"
                    />

                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.unitPrice}
                      onChange={(event) =>
                        updateItem(
                          index,
                          "unitPrice",
                          event.target.value
                        )
                      }
                      placeholder="0.00"
                    />

                    <div className="invoice-line-amount">
                      {formatCurrency(amount)}
                    </div>

                    <button
                      type="button"
                      className="invoice-remove-item"
                      onClick={() =>
                        removeItem(index)
                      }
                      title="Remove item"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* ADD ITEM */}

            <button
              type="button"
              className="invoice-add-item"
              onClick={addItem}
            >
              <Plus size={16} />
              Add Item
            </button>

            {/* TOTALS */}

            <div className="invoice-totals">
              <div>
                <span>Subtotal</span>

                <strong>
                  {formatCurrency(subtotal)}
                </strong>
              </div>

              <div>
                <span>Discount</span>

                <strong>
                  - {formatCurrency(discountAmount)}
                </strong>
              </div>

              <div>
                <span>
                  Tax ({Number(taxRate) || 0}%)
                </span>

                <strong>
                  {formatCurrency(taxAmount)}
                </strong>
              </div>

              <div className="invoice-grand-total">
                <span>Total</span>

                <strong>
                  {formatCurrency(grandTotal)}
                </strong>
              </div>
            </div>
          </section>

          {/* =================================================
              ACTIONS
              ================================================= */}

          <section className="invoice-section">
            <div className="invoice-section-header">
              <div className="invoice-step">04</div>

              <div>
                <h2>Generate Invoice</h2>

                <p>
                  Save the invoice and download a professional
                  PDF copy.
                </p>
              </div>
            </div>

            <div className="invoice-form-actions">
              <button
                type="button"
                className="invoice-reset-btn"
                onClick={resetForm}
                disabled={isGenerating}
              >
                Reset
              </button>

              <button
                type="button"
                className="invoice-generate-button"
                onClick={handleGenerateInvoice}
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <FileText size={17} />
                    Generating...
                  </>
                ) : (
                  <>
                    <Download size={17} />
                    Generate Invoice PDF
                  </>
                )}
              </button>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default Invoice;