import { useEffect, useMemo, useState } from "react";

import Sidebar from "../components/dashboard/sidebar";
import Topbar from "../components/dashboard/topbar";

import "./analytics.css";

const API_URL = "http://127.0.0.1:8000";

/* =========================================================
   HELPERS
   ========================================================= */

function getUserId() {
  const directId = localStorage.getItem("pulseiq_user_id");

  if (directId) {
    return directId;
  }

  try {
    const user = JSON.parse(
      localStorage.getItem("pulseiq_user") || "null"
    );

    return user?.id || user?.user_id || null;
  } catch {
    return null;
  }
}

function getStoredData() {
  try {
    const data = JSON.parse(
      localStorage.getItem("pulseiq_business_data") || "[]"
    );

    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function getValue(row, keys) {
  for (const key of keys) {
    if (
      row?.[key] !== undefined &&
      row?.[key] !== null &&
      row?.[key] !== ""
    ) {
      return row[key];
    }
  }

  return "";
}

function getCustomer(row) {
  return (
    getValue(row, [
      "customerName",
      "Customer Name",
      "customer",
      "Customer",
    ]) || "Unknown Customer"
  );
}

function getProduct(row) {
  return (
    getValue(row, [
      "product",
      "Product",
      "Product / Service",
      "productName",
    ]) || "Unknown Product"
  );
}

function getQuantity(row) {
  const value = Number(
    String(
      getValue(row, [
        "quantity",
        "Quantity",
        "qty",
        "Qty",
      ])
    ).replace(/,/g, "")
  );

  return Number.isFinite(value) ? value : 0;
}

function getAmount(row) {
  const value = Number(
    String(
      getValue(row, [
        "totalAmount",
        "Total Amount",
        "total",
        "Total",
        "revenue",
        "Revenue",
      ])
    ).replace(/,/g, "")
  );

  return Number.isFinite(value) ? value : 0;
}

function getPayment(row) {
  return String(
    getValue(row, [
      "paymentStatus",
      "Payment Status",
      "status",
      "Status",
    ])
  )
    .trim()
    .toLowerCase();
}

function getDate(row) {
  return getValue(row, [
    "purchaseDate",
    "Purchase Date",
    "date",
    "Date",
  ]);
}

function getInvoice(row) {
  return (
    getValue(row, [
      "invoiceId",
      "Invoice ID",
      "invoice",
      "Invoice",
    ]) || "—"
  );
}

function formatCurrency(value) {
  const amount = Number(value || 0);

  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)}Cr`;
  }

  if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(2)}L`;
  }

  if (amount >= 1000) {
    return `₹${(amount / 1000).toFixed(1)}K`;
  }

  return `₹${amount.toLocaleString("en-IN")}`;
}

function formatFullCurrency(value) {
  return `₹${Number(value || 0).toLocaleString("en-IN")}`;
}

function formatDate(dateValue) {
  if (!dateValue) return "—";

  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return String(dateValue);
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function getMonthKey(dateValue) {
  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return null;
  }

  return `${date.getFullYear()}-${String(
    date.getMonth() + 1
  ).padStart(2, "0")}`;
}

function getMonthLabel(monthKey) {
  if (!monthKey) return "Unknown";

  const [year, month] = monthKey.split("-");

  const date = new Date(
    Number(year),
    Number(month) - 1,
    1
  );

  return date.toLocaleDateString("en-IN", {
    month: "short",
    year: "numeric",
  });
}

/* =========================================================
   ANALYTICS
   ========================================================= */

function Analytics() {
  const [rows, setRows] = useState([]);

  const [dataSource, setDataSource] =
    useState("demo");

  const [loading, setLoading] =
    useState(true);

  const [productFilter, setProductFilter] =
    useState("all");

  const [paymentFilter, setPaymentFilter] =
    useState("all");

  const [dateFilter, setDateFilter] =
    useState("all");

  const [search, setSearch] =
    useState("");

  /* =======================================================
     LOAD DATA
     ======================================================= */

  const loadAnalytics = async () => {
    try {
      setLoading(true);

      /*
       * LOCAL DATA FIRST
       */

      const localData = getStoredData();

      if (localData.length > 0) {
        setRows(localData);
        setDataSource("actual");
        setLoading(false);
        return;
      }

      /*
       * BACKEND FALLBACK
       */

      const userId = getUserId();

      const response = await fetch(
        `${API_URL}/dashboard`,
        {
          headers: userId
            ? {
                "X-User-Id": String(userId),
              }
            : {},
        }
      );

      if (!response.ok) {
        throw new Error(
          "Failed to load analytics"
        );
      }

      const data =
        await response.json();

      setDataSource(
        data.source || "demo"
      );

      /*
       * Backend data does not contain complete
       * transaction rows, so only use it if
       * local data isn't available.
       */

      if (data.source === "actual") {
        setRows([]);
      } else {
        setRows([]);
      }

      setLoading(false);
    } catch (error) {
      console.error(
        "Analytics loading error:",
        error
      );

      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics();

    const handleUpdate = () => {
      loadAnalytics();
    };

    window.addEventListener(
      "pulseiq-data-updated",
      handleUpdate
    );

    window.addEventListener(
      "pulseiq-dataset-updated",
      handleUpdate
    );

    window.addEventListener(
      "storage",
      handleUpdate
    );

    return () => {
      window.removeEventListener(
        "pulseiq-data-updated",
        handleUpdate
      );

      window.removeEventListener(
        "pulseiq-dataset-updated",
        handleUpdate
      );

      window.removeEventListener(
        "storage",
        handleUpdate
      );
    };
  }, []);

  /* =======================================================
     FILTER OPTIONS
     ======================================================= */

  const products = useMemo(() => {
    return [
      ...new Set(
        rows.map((row) =>
          getProduct(row)
        )
      ),
    ].sort();
  }, [rows]);

  /* =======================================================
     FILTERED DATA
     ======================================================= */

  const filteredRows = useMemo(() => {
    let result = [...rows];

    if (productFilter !== "all") {
      result = result.filter(
        (row) =>
          getProduct(row) ===
          productFilter
      );
    }

    if (paymentFilter !== "all") {
      result = result.filter(
        (row) =>
          getPayment(row) ===
          paymentFilter
      );
    }

    if (search.trim()) {
      const query =
        search.toLowerCase();

      result = result.filter((row) => {
        const customer =
          getCustomer(row).toLowerCase();

        const product =
          getProduct(row).toLowerCase();

        const invoice =
          getInvoice(row).toLowerCase();

        return (
          customer.includes(query) ||
          product.includes(query) ||
          invoice.includes(query)
        );
      });
    }

    if (dateFilter !== "all") {
      const now = new Date();

      const days =
        Number(dateFilter);

      const startDate =
        new Date(now);

      startDate.setDate(
        now.getDate() - days
      );

      result = result.filter((row) => {
        const date = new Date(
          getDate(row)
        );

        if (Number.isNaN(date.getTime())) {
          return false;
        }

        return date >= startDate;
      });
    }

    return result;
  }, [
    rows,
    productFilter,
    paymentFilter,
    search,
    dateFilter,
  ]);

  /* =======================================================
     MAIN STATS
     ======================================================= */

  const analytics = useMemo(() => {
    let revenue = 0;
    let orders = filteredRows.length;

    const customerSet = new Set();

    let paid = 0;
    let pending = 0;

    let paidAmount = 0;
    let pendingAmount = 0;

    filteredRows.forEach((row) => {
      const amount =
        getAmount(row);

      revenue += amount;

      const customer =
        getCustomer(row);

      if (
        customer &&
        customer !==
          "Unknown Customer"
      ) {
        customerSet.add(customer);
      }

      const payment =
        getPayment(row);

      if (payment === "paid") {
        paid += 1;
        paidAmount += amount;
      }

      if (payment === "pending") {
        pending += 1;
        pendingAmount += amount;
      }
    });

    const averageOrder =
      orders > 0
        ? revenue / orders
        : 0;

    const paymentCompletion =
      paid + pending > 0
        ? Math.round(
            (paid /
              (paid + pending)) *
              100
          )
        : 0;

    return {
      revenue,
      orders,
      customers:
        customerSet.size,
      paid,
      pending,
      paidAmount,
      pendingAmount,
      averageOrder,
      paymentCompletion,
    };
  }, [filteredRows]);

  /* =======================================================
     PRODUCT PERFORMANCE
     ======================================================= */

  const productPerformance =
    useMemo(() => {
      const map = {};

      filteredRows.forEach((row) => {
        const product =
          getProduct(row);

        if (!map[product]) {
          map[product] = {
            product,
            revenue: 0,
            quantity: 0,
            orders: 0,
          };
        }

        map[product].revenue +=
          getAmount(row);

        map[product].quantity +=
          getQuantity(row);

        map[product].orders += 1;
      });

      return Object.values(map)
        .sort(
          (a, b) =>
            b.revenue - a.revenue
        )
        .slice(0, 8);
    }, [filteredRows]);

  /* =======================================================
     TOP CUSTOMERS
     ======================================================= */

  const topCustomers =
    useMemo(() => {
      const map = {};

      filteredRows.forEach((row) => {
        const customer =
          getCustomer(row);

        if (!map[customer]) {
          map[customer] = {
            customer,
            revenue: 0,
            orders: 0,
          };
        }

        map[customer].revenue +=
          getAmount(row);

        map[customer].orders += 1;
      });

      return Object.values(map)
        .sort(
          (a, b) =>
            b.revenue - a.revenue
        )
        .slice(0, 8);
    }, [filteredRows]);

  /* =======================================================
     MONTHLY REVENUE
     ======================================================= */

  const monthlyRevenue =
    useMemo(() => {
      const map = {};

      filteredRows.forEach((row) => {
        const key =
          getMonthKey(
            getDate(row)
          );

        if (!key) return;

        if (!map[key]) {
          map[key] = 0;
        }

        map[key] += getAmount(row);
      });

      return Object.entries(map)
        .sort(([a], [b]) =>
          a.localeCompare(b)
        )
        .slice(-6)
        .map(
          ([month, revenue]) => ({
            month,
            label:
              getMonthLabel(month),
            revenue,
          })
        );
    }, [filteredRows]);

  /* =======================================================
     BEST PRODUCT
     ======================================================= */

  const bestProduct =
    productPerformance[0] || null;

  /* =======================================================
     RECENT TRANSACTIONS
     ======================================================= */

  const recentTransactions =
    useMemo(() => {
      return [...filteredRows]
        .sort((a, b) => {
          const dateA =
            new Date(getDate(a));

          const dateB =
            new Date(getDate(b));

          return (
            dateB.getTime() -
            dateA.getTime()
          );
        })
        .slice(0, 6);
    }, [filteredRows]);

  /* =======================================================
     RENDER
     ======================================================= */

  return (
    <div className="dashboard-shell">

      <Sidebar />

      <div className="dashboard-main">

        <Topbar />

        <main className="dashboard-content analytics-page">

          {/* =================================================
              HEADER
              ================================================= */}

          <div className="page-heading">

            <div>
              <span className="eyebrow">
                PERFORMANCE
              </span>

              <h1>Analytics</h1>

              <p>
                Understand your revenue,
                customers and business
                performance.
              </p>
            </div>

            <div className="dashboard-heading-actions">

              <span className="demo-badge">
                {dataSource === "actual"
                  ? "LIVE DATA"
                  : "DEMO DATA"}
              </span>

            </div>

          </div>

          {/* =================================================
              FILTERS
              ================================================= */}

          <div className="analytics-filters">

            <div className="analytics-filter-group">

              <label>
                Date
              </label>

              <select
                value={dateFilter}
                onChange={(e) =>
                  setDateFilter(
                    e.target.value
                  )
                }
              >
                <option value="all">
                  All Time
                </option>

                <option value="7">
                  Last 7 Days
                </option>

                <option value="30">
                  Last 30 Days
                </option>

                <option value="90">
                  Last 90 Days
                </option>
              </select>

            </div>

            <div className="analytics-filter-group">

              <label>
                Product
              </label>

              <select
                value={productFilter}
                onChange={(e) =>
                  setProductFilter(
                    e.target.value
                  )
                }
              >
                <option value="all">
                  All Products
                </option>

                {products.map(
                  (product) => (
                    <option
                      key={product}
                      value={product}
                    >
                      {product}
                    </option>
                  )
                )}
              </select>

            </div>

            <div className="analytics-filter-group">

              <label>
                Payment
              </label>

              <select
                value={paymentFilter}
                onChange={(e) =>
                  setPaymentFilter(
                    e.target.value
                  )
                }
              >
                <option value="all">
                  All Payments
                </option>

                <option value="paid">
                  Paid
                </option>

                <option value="pending">
                  Pending
                </option>

              </select>

            </div>

            <div className="analytics-search">

              <label>
                Search
              </label>

              <input
                type="text"
                placeholder="Customer, product or invoice..."
                value={search}
                onChange={(e) =>
                  setSearch(
                    e.target.value
                  )
                }
              />

            </div>

            <button
              className="analytics-reset"
              onClick={() => {
                setProductFilter("all");
                setPaymentFilter("all");
                setDateFilter("all");
                setSearch("");
              }}
            >
              Reset
            </button>

          </div>

          {/* =================================================
              STATS
              ================================================= */}

          <div className="analytics-stats-grid">

            <div className="analytics-stat-card">

              <span className="analytics-stat-badge">
                LIVE
              </span>

              <p className="analytics-stat-label">
                Revenue
              </p>

              <h2 className="analytics-stat-value">
                {loading
                  ? "..."
                  : formatCurrency(
                      analytics.revenue
                    )}
              </h2>

            </div>

            <div className="analytics-stat-card">

              <span className="analytics-stat-badge">
                LIVE
              </span>

              <p className="analytics-stat-label">
                Orders
              </p>

              <h2 className="analytics-stat-value">
                {loading
                  ? "..."
                  : analytics.orders.toLocaleString(
                      "en-IN"
                    )}
              </h2>

            </div>

            <div className="analytics-stat-card">

              <span className="analytics-stat-badge">
                LIVE
              </span>

              <p className="analytics-stat-label">
                Customers
              </p>

              <h2 className="analytics-stat-value">
                {loading
                  ? "..."
                  : analytics.customers.toLocaleString(
                      "en-IN"
                    )}
              </h2>

            </div>

            <div className="analytics-stat-card">

              <span className="analytics-stat-badge">
                AOV
              </span>

              <p className="analytics-stat-label">
                Average Order
              </p>

              <h2 className="analytics-stat-value">
                {loading
                  ? "..."
                  : formatCurrency(
                      analytics.averageOrder
                    )}
              </h2>

            </div>

          </div>

          {/* =================================================
              REVENUE TREND
              ================================================= */}

          <div className="analytics-section-card analytics-revenue-section">

            <div className="analytics-section-header">

              <div>
                <span className="eyebrow">
                  REVENUE
                </span>

                <h2>
                  Revenue Trend
                </h2>

                <p>
                  Revenue performance over
                  the available period.
                </p>
              </div>

              <strong className="analytics-section-total">
                {formatFullCurrency(
                  analytics.revenue
                )}
              </strong>

            </div>

            {monthlyRevenue.length === 0 ? (

              <div className="analytics-empty">
                <strong>
                  No revenue data available
                </strong>

                <span>
                  Add business data or
                  upload a CSV to see
                  your revenue trend.
                </span>
              </div>

            ) : (

              <div className="revenue-bars">

                {monthlyRevenue.map(
                  (item) => {

                    const maxRevenue =
                      Math.max(
                        ...monthlyRevenue.map(
                          (entry) =>
                            entry.revenue
                        )
                      );

                    const height =
                      maxRevenue > 0
                        ? Math.max(
                            8,
                            (item.revenue /
                              maxRevenue) *
                              100
                          )
                        : 8;

                    return (
                      <div
                        className="revenue-bar-column"
                        key={item.month}
                      >

                        <div className="revenue-bar-value">
                          {formatCurrency(
                            item.revenue
                          )}
                        </div>

                        <div className="revenue-bar-track">

                          <div
                            className="revenue-bar-fill"
                            style={{
                              height: `${height}%`,
                            }}
                          />

                        </div>

                        <span>
                          {item.label}
                        </span>

                      </div>
                    );
                  }
                )}

              </div>

            )}

          </div>

          {/* =================================================
              PRODUCT + PAYMENT
              ================================================= */}

          <div className="analytics-two-column">

            {/* PRODUCT */}

            <div className="analytics-section-card">

              <div className="analytics-section-header">

                <div>
                  <span className="eyebrow">
                    PRODUCTS
                  </span>

                  <h2>
                    Product Performance
                  </h2>

                  <p>
                    Your highest revenue
                    products.
                  </p>
                </div>

              </div>

              {productPerformance.length ===
              0 ? (

                <div className="analytics-empty">
                  No product data
                  available.
                </div>

              ) : (

                <div className="analytics-list">

                  {productPerformance.map(
                    (item, index) => {

                      const max =
                        productPerformance[0]
                          ?.revenue || 1;

                      const percentage =
                        Math.round(
                          (item.revenue /
                            max) *
                            100
                        );

                      return (
                        <div
                          className="product-performance-row"
                          key={
                            item.product
                          }
                        >

                          <div className="product-rank">
                            #{index + 1}
                          </div>

                          <div className="product-performance-main">

                            <div className="product-performance-top">

                              <strong>
                                {
                                  item.product
                                }
                              </strong>

                              <strong>
                                {formatCurrency(
                                  item.revenue
                                )}
                              </strong>

                            </div>

                            <div className="product-progress">

                              <div
                                className="product-progress-fill"
                                style={{
                                  width: `${percentage}%`,
                                }}
                              />

                            </div>

                            <span>
                              {item.quantity.toLocaleString(
                                "en-IN"
                              )}{" "}
                              units •{" "}
                              {item.orders}{" "}
                              orders
                            </span>

                          </div>

                        </div>
                      );
                    }
                  )}

                </div>

              )}

            </div>

            {/* PAYMENT */}

            <div className="analytics-section-card">

              <div className="analytics-section-header">

                <div>
                  <span className="eyebrow">
                    PAYMENTS
                  </span>

                  <h2>
                    Payment Analysis
                  </h2>

                  <p>
                    Payment collection
                    overview.
                  </p>
                </div>

              </div>

              <div className="payment-summary">

                <div className="payment-box">

                  <span>
                    Paid
                  </span>

                  <strong>
                    {analytics.paid}
                  </strong>

                  <small>
                    {formatCurrency(
                      analytics.paidAmount
                    )}
                  </small>

                </div>

                <div className="payment-box">

                  <span>
                    Pending
                  </span>

                  <strong>
                    {analytics.pending}
                  </strong>

                  <small>
                    {formatCurrency(
                      analytics.pendingAmount
                    )}
                  </small>

                </div>

              </div>

              <div className="payment-progress">

                <div className="payment-progress-label">

                  <span>
                    Collection rate
                  </span>

                  <strong>
                    {
                      analytics.paymentCompletion
                    }
                    %
                  </strong>

                </div>

                <div className="payment-progress-track">

                  <div
                    className="payment-progress-fill"
                    style={{
                      width: `${analytics.paymentCompletion}%`,
                    }}
                  />

                </div>

              </div>

              <div className="payment-total">

                <span>
                  Total outstanding
                </span>

                <strong>
                  {formatCurrency(
                    analytics.pendingAmount
                  )}
                </strong>

              </div>

            </div>

          </div>

          {/* =================================================
              TOP CUSTOMERS
              ================================================= */}

          <div className="analytics-section-card">

            <div className="analytics-section-header">

              <div>
                <span className="eyebrow">
                  CUSTOMERS
                </span>

                <h2>
                  Top Customers
                </h2>

                <p>
                  Customers generating the
                  most revenue.
                </p>
              </div>

            </div>

            {topCustomers.length ===
            0 ? (

              <div className="analytics-empty">
                No customer data
                available.
              </div>

            ) : (

              <div className="customer-performance-grid">

                {topCustomers.map(
                  (customer, index) => (
                    <div
                      className="customer-performance-card"
                      key={
                        customer.customer
                      }
                    >

                      <div className="customer-rank">
                        #{index + 1}
                      </div>

                      <div className="customer-avatar">
                        {customer.customer
                          .charAt(0)
                          .toUpperCase()}
                      </div>

                      <div className="customer-performance-info">

                        <strong>
                          {
                            customer.customer
                          }
                        </strong>

                        <span>
                          {customer.orders}{" "}
                          {customer.orders ===
                          1
                            ? "order"
                            : "orders"}
                        </span>

                      </div>

                      <strong className="customer-performance-revenue">
                        {formatCurrency(
                          customer.revenue
                        )}
                      </strong>

                    </div>
                  )
                )}

              </div>

            )}

          </div>

          {/* =================================================
              BEST PRODUCT
              ================================================= */}

          {bestProduct && (
            <div className="analytics-highlight-card">

              <div className="highlight-icon">
                ★
              </div>

              <div>
                <span>
                  BEST PERFORMING PRODUCT
                </span>

                <strong>
                  {bestProduct.product}
                </strong>

                <p>
                  Generated{" "}
                  {formatFullCurrency(
                    bestProduct.revenue
                  )}{" "}
                  in revenue from{" "}
                  {bestProduct.orders}{" "}
                  orders.
                </p>
              </div>

            </div>
          )}

          {/* =================================================
              RECENT TRANSACTIONS
              ================================================= */}

          <div className="analytics-section-card">

            <div className="analytics-section-header">

              <div>
                <span className="eyebrow">
                  ACTIVITY
                </span>

                <h2>
                  Recent Transactions
                </h2>

                <p>
                  Latest business
                  transactions.
                </p>
              </div>

            </div>

            {recentTransactions.length ===
            0 ? (

              <div className="analytics-empty">
                No transactions available.
              </div>

            ) : (

              <div className="analytics-table-wrapper">

                <table className="analytics-table">

                  <thead>
                    <tr>
                      <th>
                        Customer
                      </th>

                      <th>
                        Product
                      </th>

                      <th>
                        Invoice
                      </th>

                      <th>
                        Date
                      </th>

                      <th>
                        Status
                      </th>

                      <th>
                        Amount
                      </th>
                    </tr>
                  </thead>

                  <tbody>

                    {recentTransactions.map(
                      (row, index) => {

                        const status =
                          getPayment(
                            row
                          );

                        return (
                          <tr
                            key={`${getInvoice(
                              row
                            )}-${index}`}
                          >

                            <td>
                              <strong>
                                {getCustomer(
                                  row
                                )}
                              </strong>
                            </td>

                            <td>
                              {getProduct(
                                row
                              )}
                            </td>

                            <td>
                              {getInvoice(
                                row
                              )}
                            </td>

                            <td>
                              {formatDate(
                                getDate(
                                  row
                                )
                              )}
                            </td>

                            <td>

                              <span
                                className={`payment-status ${
                                  status ===
                                  "paid"
                                    ? "paid"
                                    : "pending"
                                }`}
                              >
                                {status ===
                                "paid"
                                  ? "Paid"
                                  : status ===
                                    "pending"
                                  ? "Pending"
                                  : "Unknown"}
                              </span>

                            </td>

                            <td>
                              <strong>
                                {formatFullCurrency(
                                  getAmount(
                                    row
                                  )
                                )}
                              </strong>
                            </td>

                          </tr>
                        );
                      }
                    )}

                  </tbody>

                </table>

              </div>

            )}

          </div>

        </main>

      </div>

    </div>
  );
}

export default Analytics;